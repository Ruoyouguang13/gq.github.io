import numpy as np
import torch
import cv2
import warnings
from sklearn.cluster import KMeans
warnings.filterwarnings('ignore')
import sys
sys.path.append("MobileSAM-master")
sys.path.append('yolov10_main')
from ultralytics import YOLOv10
from mobile_encoder.setup_mobile_sam import setup_model
from segment_anything import SamPredictor

def add_mask(image, mask):
    """
    将分割的 mask 叠加到原始图像
    """
    int_mask = mask.astype(np.uint8) * 255
    int_mask_3d = np.dstack((int_mask, int_mask, int_mask))  # 转为三通道
    black_areas = int_mask_3d == 0  # 获取黑色区域（非 mask 区域）
    res = cv2.addWeighted(image, 0.6, int_mask_3d, 1 - 0.6, 0, dtype=cv2.CV_8U)  # 叠加 mask 到原图
    res[black_areas] = image[black_areas]  # 保留原图未覆盖部分
    return res

def get_bounding_boxes(mask):
    """
    根据 mask 提取边界框
    """
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = [cv2.boundingRect(cnt) for cnt in contours]
    boxes = [[x, y, x + w, y + h] for (x, y, w, h) in boxes]  # 转为 [x_min, y_min, x_max, y_max]
    return boxes

def recursive_sam(image, predictor, initial_boxes):
    """
    递归进行 SAM 分割，直到分割区域不变
    """
    prev_mask = None
    combined_mask = np.zeros(image.shape[:2], dtype=bool)  # 初始化总 mask
    boxes = initial_boxes

    while True:
        new_combined_mask = np.zeros(image.shape[:2], dtype=bool)  # 每次迭代的总 mask
        for box in boxes:
            input_box = np.array([box[0], box[1], box[2], box[3]])
            masks, _, _ = predictor.predict(
                point_coords=None,
                point_labels=None,
                box=input_box[None, :],
                multimask_output=False,
            )
            new_combined_mask = np.logical_or(new_combined_mask, masks[0])  # 合并新的 mask

        # 判断分割是否稳定
        if prev_mask is not None and np.array_equal(new_combined_mask, prev_mask):
            break  # 如果新旧 mask 相同，则停止递归

        prev_mask = new_combined_mask
        combined_mask = np.logical_or(combined_mask, new_combined_mask)  # 更新总 mask
        boxes = get_bounding_boxes(new_combined_mask)  # 更新边界框

    return combined_mask

def color_based_segmentation(image, mask):
    """
    在 SAM 分割区域内基于颜色的进一步分割
    """
    # 提取分割区域
    region = cv2.bitwise_and(image, image, mask=mask.astype(np.uint8))
    region_flat = region.reshape(-1, 3)  # 将图像数据展开为 [像素数, 3]

    # 去除全零像素
    non_zero_idx = np.any(region_flat > 0, axis=1)
    region_flat = region_flat[non_zero_idx]

    # 使用 KMeans 进行颜色聚类
    kmeans = KMeans(n_clusters=3, random_state=42).fit(region_flat)
    labels = kmeans.predict(region.reshape(-1, 3))
    segmented_image = labels.reshape(image.shape[:2])

    # 计算每个聚类的颜色出现频率
    unique, counts = np.unique(labels, return_counts=True)
    color_frequencies = dict(zip(unique, counts))

    # 找到最多的颜色类别
    max_color = max(color_frequencies, key=color_frequencies.get)

    # 创建掩码，将最多的颜色作为一类，其他作为一类
    binary_mask = (segmented_image == max_color).astype(np.uint8)

    # 创建“其他颜色”的掩码
    other_color_mask = (segmented_image != max_color).astype(np.uint8)

    return binary_mask, other_color_mask



# def color_based_segmentation(image, mask):
#     """
#     在 SAM 分割区域内基于颜色的进一步分割，并处理“其他颜色”区域
#     """
#     # 提取分割区域
#     region = cv2.bitwise_and(image, image, mask=mask.astype(np.uint8))
#     region_flat = region.reshape(-1, 3)  # 将图像数据展开为 [像素数, 3]
#
#     # 去除全零像素
#     non_zero_idx = np.any(region_flat > 0, axis=1)
#     region_flat = region_flat[non_zero_idx]
#
#     # 使用 KMeans 进行颜色聚类
#     kmeans = KMeans(n_clusters=3, random_state=42).fit(region_flat)
#     labels = kmeans.predict(region.reshape(-1, 3))
#     segmented_image = labels.reshape(image.shape[:2])
#
#     # 计算每个聚类的颜色出现频率
#     unique, counts = np.unique(labels, return_counts=True)
#     color_frequencies = dict(zip(unique, counts))
#
#     # 找到最多的颜色类别
#     max_color = max(color_frequencies, key=color_frequencies.get)
#
#     # 创建掩码，将最多的颜色作为一类，其他作为一类
#     binary_mask = (segmented_image == max_color).astype(np.uint8)
#     other_color_mask = (segmented_image != max_color).astype(np.uint8)
#
#     # 将“其他颜色”的区域改为白色
#     white_other_color_region = np.ones_like(image) * 255  # 创建一个全白图像
#     white_other_color_region = cv2.bitwise_and(white_other_color_region, white_other_color_region, mask=other_color_mask)
#
#     # 进行闭运算，先膨胀再腐蚀
#     kernel = np.ones((3, 3), np.uint8)  # 定义结构元素
#     closed_other_color_region = cv2.morphologyEx(white_other_color_region, cv2.MORPH_CLOSE, kernel)
#
#     return binary_mask, closed_other_color_region



# 读取图像
image_path = r'E:\DJI_0043.JPG'
image = cv2.imread(image_path)  # 原始分辨率图像
original_height, original_width = image.shape[:2]

# 加载 YOLOv10 模型
model = YOLOv10(r"D:\yolov10\runs\detect\CMFinally\weights\best.pt")
results = model.predict(image)  # YOLO 会对图像进行内部缩放
res = results[0]

# 获取 YOLO 的检测框，并将其映射回原始分辨率
box_locations = res.boxes.xyxy.cpu().numpy()
scale_x = original_width / res.orig_shape[1]  # 横向缩放比例
scale_y = original_height / res.orig_shape[0]  # 纵向缩放比例
box_locations = box_locations * [scale_x, scale_y, scale_x, scale_y]
box_locations = box_locations.astype(int)  # 转为整数坐标

# 加载 MobileSAM 模型
checkpoint = torch.load(r'D:\yolov10\MobileSAM-master\MobileSAM-master\weights\mobile_sam.pt', map_location=torch.device('cpu'))
mobile_sam = setup_model()
mobile_sam.load_state_dict(checkpoint, strict=True)
device = "cpu"
mobile_sam.to(device=device)
mobile_sam.eval()

# 将原始分辨率图像传入 SAM
predictor = SamPredictor(mobile_sam)
predictor.set_image(image)  # 使用原始分辨率图像

# 递归分割
print("Performing recursive SAM segmentation...")
final_mask = recursive_sam(image, predictor, box_locations)

# 在分割区域内基于颜色的进一步分割
binary_mask, other_color_mask = color_based_segmentation(image, final_mask)

# 将“其他颜色”的区域改为白色
white_other_color_region = np.ones_like(image) * 255  # 创建一个全白图像
white_other_color_region = cv2.bitwise_and(white_other_color_region, white_other_color_region, mask=other_color_mask)

# 进行闭运算，先膨胀再腐蚀
kernel = np.ones((3, 3), np.uint8)  # 定义结构元素
closed_other_color_region = cv2.morphologyEx(white_other_color_region, cv2.MORPH_CLOSE, kernel)

# 转换为灰度图
gray_closed_region = cv2.cvtColor(closed_other_color_region, cv2.COLOR_BGR2GRAY)

# 提取轮廓
contours, _ = cv2.findContours(gray_closed_region, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# 分别计算每个白色色块的面积
areas = [cv2.contourArea(cnt) for cnt in contours]

# 计算总面积
total_area = sum(areas)

# 输出每个色块面积和总面积
print("每个白色色块的面积:", areas)
print("白色色块的总面积:", total_area)

# 统计闭运算后白色像素点的个数（备选方法）
white_pixel_count = np.sum(gray_closed_region == 255)
print(f"闭运算后白色像素点的个数为: {white_pixel_count}")

# 显示并保存每种颜色的分割结果
segmented_region = cv2.bitwise_and(image, image, mask=binary_mask)
cv2.imwrite(f"res_max_color.jpg", segmented_region)
cv2.imshow(f"Max Color Region", segmented_region)

cv2.imwrite(f"res_other_color_white_closed.jpg", closed_other_color_region)
cv2.imshow(f"Other Color Region (White and Closed)", closed_other_color_region)

cv2.waitKey(0)
