import os
import numpy as np
import torch
import cv2
from sklearn.cluster import KMeans
from ultralytics import YOLOv10
from mobile_encoder.setup_mobile_sam import setup_model
from segment_anything import SamPredictor

# 递归 SAM 分割函数
def recursive_sam(image, predictor, initial_boxes):
    prev_mask = None
    combined_mask = np.zeros(image.shape[:2], dtype=bool)
    boxes = initial_boxes

    while True:
        new_combined_mask = np.zeros(image.shape[:2], dtype=bool)
        for box in boxes:
            input_box = np.array([box[0], box[1], box[2], box[3]])
            masks, _, _ = predictor.predict(
                point_coords=None,
                point_labels=None,
                box=input_box[None, :],
                multimask_output=False,
            )
            new_combined_mask = np.logical_or(new_combined_mask, masks[0])

        if prev_mask is not None and np.array_equal(new_combined_mask, prev_mask):
            break

        prev_mask = new_combined_mask
        combined_mask = np.logical_or(combined_mask, new_combined_mask)
        boxes = get_bounding_boxes(new_combined_mask)

    return combined_mask

# 计算边界框
def get_bounding_boxes(mask):
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = [cv2.boundingRect(cnt) for cnt in contours]
    boxes = [[x, y, x + w, y + h] for (x, y, w, h) in boxes]
    return boxes

# 计算 Precision 和 IoU
def compute_metrics(pred_mask, gt_mask):
    pred_mask = pred_mask.astype(bool)
    gt_mask = gt_mask.astype(bool)

    TP = np.logical_and(pred_mask, gt_mask).sum()
    FP = np.logical_and(pred_mask, np.logical_not(gt_mask)).sum()
    FN = np.logical_and(np.logical_not(pred_mask), gt_mask).sum()

    precision = TP / (TP + FP) if (TP + FP) > 0 else 0
    iou = TP / (TP + FP + FN) if (TP + FP + FN) > 0 else 0

    return precision, iou

# 计算 mIoU
def compute_mIoU(pred_mask, gt_mask, num_classes=2):
    ious = []
    for cls in range(1, num_classes):  # 0 是背景
        pred_cls = pred_mask == cls
        gt_cls = gt_mask == cls
        iou = compute_metrics(pred_cls, gt_cls)[1]
        ious.append(iou)
    return np.mean(ious)

# 加载 YOLOv10 模型
model = YOLOv10(r"D:\yolov10\runs\detect\CMFinally\weights\best.pt")

# 加载 MobileSAM 模型
checkpoint = torch.load(r'D:\yolov10\MobileSAM-master\MobileSAM-master\weights\mobile_sam.pt', map_location=torch.device('cpu'))
mobile_sam = setup_model()
mobile_sam.load_state_dict(checkpoint, strict=True)
device = "cpu"
mobile_sam.to(device=device)
mobile_sam.eval()
predictor = SamPredictor(mobile_sam)

# 读取数据集路径
image_folder = r"D:\yolov10\sam_miou_P_labes\image"  # JPG 图像目录
mask_folder = r"D:\yolov10\sam_miou_P_labes\masks"  # 二值标签目录

# 读取所有图片
image_files = [f for f in os.listdir(image_folder) if f.endswith('.JPG')]
mask_files = {f.split('.')[0]: os.path.join(mask_folder, f) for f in os.listdir(mask_folder) if f.endswith('.png')}

# 结果统计
all_precisions = []
all_mIoUs = []

for image_file in image_files:
    image_path = os.path.join(image_folder, image_file)
    mask_name = image_file.split('.')[0]  # 去掉扩展名
    mask_path = mask_files.get(mask_name, None)

    if mask_path is None:
        print(f"没有找到 {image_file} 对应的 mask，跳过...")
        continue

    # 读取图片
    image = cv2.imread(image_path)
    original_height, original_width = image.shape[:2]

    # 读取 Ground Truth mask
    gt_mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    gt_mask = gt_mask > 127  # 转换为二值

    # 使用 YOLO 进行检测
    results = model.predict(image)
    res = results[0]

    # 获取 YOLO 检测框
    box_locations = res.boxes.xyxy.cpu().numpy()
    scale_x = original_width / res.orig_shape[1]
    scale_y = original_height / res.orig_shape[0]
    box_locations = box_locations * [scale_x, scale_y, scale_x, scale_y]
    box_locations = box_locations.astype(int)

    # 进行 SAM 分割
    predictor.set_image(image)
    print(f"Processing {image_file} ...")
    final_mask = recursive_sam(image, predictor, box_locations)

    # 计算 Precision 和 IoU
    precision, iou = compute_metrics(final_mask, gt_mask)
    mIoU = compute_mIoU(final_mask, gt_mask)

    print(f"Image: {image_file} | Precision: {precision:.4f} | mIoU: {mIoU:.4f}")

    all_precisions.append(precision)
    all_mIoUs.append(mIoU)

# 计算整体平均 Precision 和 mIoU
mean_precision = np.mean(all_precisions)
mean_mIoU = np.mean(all_mIoUs)

print(f"\n【所有图片的平均 Precision】: {mean_precision:.4f}")
print(f"【所有图片的平均 mIoU】: {mean_mIoU:.4f}")