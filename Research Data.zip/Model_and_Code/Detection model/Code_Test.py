from ultralytics import YOLOv10
import cv2
import matplotlib.pyplot as plt

if __name__ == '__main__':
    # Load a model
    # model = YOLOv10('yolov10n.pt')  # load an official model
    model = YOLOv10(r'D:\yolov10\runs\detect\x100\weights\best.pt')  # 使用训练好的模型

    # Validate the model
    metrics = model.val(data=r'D:\yolov10\film.yaml', split='test', save = True)  # 验证模型，使用指定的数据集和设置

