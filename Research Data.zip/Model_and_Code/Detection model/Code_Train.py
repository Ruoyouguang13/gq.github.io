from ultralytics import YOLOv10

if __name__ == '__main__':
# Load a model # 三选一
    #model = YOLOv10.from_pretrained('jameslahm/yolov10n')
    model = YOLOv10('yolov10n.pt')  # load a pretrained model (recommended for training)
    #start_epoch = 401

# Train the model
    model.train(data=r'D:\yolov10\film.yaml', epochs=800, imgsz=640, device = 0, batch = 4)

